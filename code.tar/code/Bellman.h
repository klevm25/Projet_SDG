/* bellman.h */
#if ! defined (BELLMAN_H)
#define BELLMAN_H 1

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Split.h"


extern void Bellman(struct liste*,double** ,int* ,double* ,int );

#endif