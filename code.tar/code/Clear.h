/* Clear.h */

/* prototypes */

extern void clear_donnee(int* ,double** t,int* ,struct liste* ,int*,double*,struct liste_sommet*,int);
