/* lecture.h */
#if ! defined (LECTURE_H)
#define LECTURE_H 1

#include <stdio.h>
#include <stdlib.h>



// Prototype 

extern int * LectureQuantite(int);

extern double ** LectureDist(int);

extern void Lecture(int*,int*, int*, double***, int**);

#endif




